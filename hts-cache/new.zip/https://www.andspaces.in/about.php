
<!DOCTYPE html>
<html lang="en">
<head>
	<title>About Andspaces</title>
	<meta charset="UTF-8">
	<meta name="description" content="Arcade - Architecture Template">
	<meta name="keywords" content="arcade, architecture, onepage, creative, html">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<!-- Favicon -->   
	<link href="img/favicon.ico" rel="shortcut icon"/>

	<!-- Google Fonts -->
	<link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700" rel="stylesheet">

	<!-- Stylesheets -->
	<link rel="stylesheet" href="css/bootstrap.min.css"/>
	<link rel="stylesheet" href="css/font-awesome.min.css"/>
	<link rel="stylesheet" href="css/animate.css"/>
	<link rel="stylesheet" href="css/owl.carousel.css"/>

	<!--====== Javascripts & Jquery ======-->
	<script src="js/jquery.min.js"></script>


	<!--[if lt IE 9]>
	  <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
	  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
	<![endif]-->

	<style type="text/css">
		.unscrolled_header img {
			content: url(img/logoLight_Small.png) !important;
		}
		.unscrolled_header h3,
		.unscrolled_header p,
		.unscrolled_header a {
			color: #fff !important;
		}
		.slide-num-holder span {
			color: #00000075;
		}
	</style>

</head>
<body>
	<!-- Page Preloder -->
	<div id="preloder" style="background-color: #f7edec">
	<div class="loader" style="width: 100%; max-width: 120px; text-align: center;">
		<object>
			<embed src="img/animated_logo_dark.svg"></embed>
		</object>
		<!-- <p>Please Wait</p> -->
	</div>
</div>	
	<!-- Header section start -->   
	<img src="img/logoDark_Small.png" style="display: none;">

	

<link rel="stylesheet" href="css/style.css?v2.4"/>

<link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
<script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
<script>
  AOS.init();
</script>

<link href="https://fonts.googleapis.com/css?family=Poppins:200,400,500,700|Roboto:300,400,500,700&display=swap" rel="stylesheet">

<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">

<!-- <link rel="stylesheet" href="css/custom_cursor.css">   -->

<nav id="headerID" class="header-area unscrolled_header">
	<a href="index.php" class="logo-area">
		<img src="img/logoDark_Small.png" alt="">
	</a>
	<div style="display: flex;flex-direction: column;align-items: flex-start;justify-content: center;/* line-height: 0.5; *//* height: 100%; */">
		<h3 style="letter-spacing: 0.2em;">AndSpaces</h3>
		<p>Architecture - Interior</p>
	</div>

	<div class="nav-switch">
		<i class="fa fa-bars"></i>
	</div>

	<nav class="nav-menu" style="margin-top: -40px; flex: 1; flex-grow: 1;">
		<ul style="float: right;">
			<li id="navbarMenuItemHome"><a href="index.php" style="display: inline-flex; flex-direction: row; align-items: center; justify-content: flex-start;"><i class="fas fa-home"></i><span style="margin-left: 8px;" class="onlyForMobile">Home</span></a></li>
			<li id="navbarMenuItemAbout"><a href="about.php">What is AndSpaces?</a></li>
			<li id="navbarMenuItemPortfolio"><a href="portfolio.php">Our Work</a></li>
			<li id="navbarMenuItemContact"><a href="contact.php"><i class="fas fa-phone" style="transform: rotate(90deg); margin-right: 8px;"></i>Contact</a></li>
			<li id="navbarMenuItemPay"><a href="pay" target="_BLANK"><i class="fas fa-credit-card" style="margin-right: 8px;"></i>Pay</a></li>
		</ul>
	</nav>
</nav>

<script type="text/javascript">
	
	function navOnPage(pageID) {
		$("#" + pageID).addClass("active");
	}

</script>

<!-- <link rel="stylesheet" type="text/css" href="css/dark_theme.css"> -->
	<script type="text/javascript">
		navOnPage("navbarMenuItemAbout");	
	</script>
	<!-- Header section end -->   


	<!-- Page header section start -->

	
		<section class='page-header-section' style='background-color: #30303e; background-image: url(img/projects/2/4.jpg); background-size: cover; background-position: center; background-repeat: no-repeat; background-blend-mode: overlay;'>
			<div class='container'>
				<h1 class='header-title' data-aos='fade-right'>About us<span>.</span></h1>
			</div>
		</section>
			<!-- Page header section end -->



	<!-- Intro section start -->
	<section class="intro-section spad">
		<div class="container">
			<div class="row">
				<div class="col-lg-8 intro-text" data-aos="fade-right">
					<h1 style="line-height: 1.5;
					">We don’t just design spaces, <br>We create <span class="coloredSpan">Ambience</span></h1>
					<div class="row">
						<div style="width: 100%; max-width: 80%; text-align: justify;">
							<p>"One of the great beauties of architecture is that each time, it is like life starting all over again", said by a great architect, Renzo Piano. This truly defines what we believe in. Our values lie at the very foundation of architecture and design, we believe in crafting fully functional and stylish designs that speak for themselves. That's why we say, we don't just design spaces we create an aura! </p>
						</div>
					</div>
				</div>
				<div class="col-lg-4" data-aos="fade-left">
					<img src="img/projects/1/5.jpg" alt="" style="border-radius: 5px;">
				</div>
			</div>
		</div>
	</section>
	<!-- Intro section end -->


	<!-- Testimonials section start -->
	<section class="testimonials-section spad">
		<div class="testimonials-image-box" style="background-image: url(img/quote.png);background-size: contain;background-position: center;opacity: 0.1;"></div>
		<div class="container">
			<div class="row">
				<div class="col-lg-7 pl-lg-0 offset-lg-5 cta-content">
					<h1>What are people saying...</h1>
					<div class="qut">“</div>
					<div class="testimonials-slider" id="test-slider">
						
									<div class='ts-item'>
										<p>I am extremely happy with the conceptual and interior designs created by Ankita for our house in Pune. She also had it all fixed by herself, thus not bothering us for anything. All architectural and interior services under one roof. Big thanks to Ankita.</p>
										<h4>Harshadeep Kamble</h4>
										<span>IAS, Commissioner for Industries, Mumbai</span>
									</div>
									
									<div class='ts-item'>
										<p>They say that a home is incomplete without a tinge of love and that is what Ankita adds to her work when she transforms a house into a home.</p>
										<h4>Col K C Mishra</h4>
										<span>VSM - Former Chief Postmaster General Maharashtra and Goa States</span>
									</div>
														</div>
					<div class="slide-num-holder test-slider" id="snh-2" style="color: #000; background-color: #f1dcdc;"></div>
				</div>
			</div>
		</div>
	</section>
	<!-- Testimonials section end -->



	<!-- Team section start -->
	<section class="team-section spad">
		<div class="container">
<!-- 			<div class="section-title mb100">
				<h1><span class="coloredSpan">Founders</span> words</h1>
			</div> -->
			<div class="row">
				<div class="col-lg-5 col-md-4">
					<div class="team-member">
						<div style="height: 350px; width: 90%; background-image: url(img/team/ankita_nand.jpeg); background-size: cover; background-position: center; background-repeat: no-repeat; border-radius: 10px;"></div>
						<div class="member-info" style="background-color: #faebeb;">
							<h2>Ankita Nand-Deshmukh</h2>
							<p>Founder & Sr. Architect</p>
						</div>
					</div>
				</div>
				<div class="col-lg-6 intro-text">
					
					<div class="row">
						<div class="section-title mb100" style="
						    text-align: left;
						    padding: 0;
						    margin-bottom: 30px;
						">
										<h1 style="
						    padding: 0;
						"><span class="coloredSpan">Founder's</span> Words</h1>
									</div>
						<div style="width: 100%; text-align: justify;">
							<p>My vision has always been to create spaces from scratch according to the fundamental requirements, fully functional and stylish at the same time. Our objective simply is 'Not to be boring but innovative'. We at AndSpaces try to evolve our designs embracing every new thing that we come across. We weave interior and exterior spaces, from big architectural ideas to the smallest interior detail, and thus, we try to personalise every single wall in a space.</p>
						</div>
					</div>
				</div>


			</div>

			<div class="section-title" style="display: grid; grid-template-columns: auto auto 1fr; align-items: center; margin: 80px 0 50px 0;">
					<hr style="width: 5vw; height: 1px; border: none; background-color: var(--colorDark)">
					<h1>The <span class="coloredSpan">Team</span></h1>
					<hr style="width: 100%; height: 1px; border: none; background-color: var(--colorDark)">
				</div>
				
				<div class="small_team_container" style="display: grid; grid-template-columns: repeat(3, minmax(200px, 1fr)); grid-gap: 30px; margin-top: 80px;">
					
									<div>
										<div class='team-member small'>
											<div class='picture' style='background-image: url(img/team/raaj_deshmukh.jpeg); background-size: cover; background-position: center; background-repeat: no-repeat;'></div>
											<div class='member-info'>
												<h2>Raaj S. Deshmukh</h2>
												<p>Co-founder</p>
											</div>
										</div>
									</div>
								
									<div>
										<div class='team-member small'>
											<div class='picture' style='background-image: url(img/team/mr_nand.jpeg); background-size: cover; background-position: center; background-repeat: no-repeat;'></div>
											<div class='member-info'>
												<h2>Pradip Nand</h2>
												<p>Investor and Mentor</p>
											</div>
										</div>
									</div>
								
									<div>
										<div class='team-member small'>
											<div class='picture' style='background-image: url(img/team/sl_deshmukh.jpg); background-size: cover; background-position: center; background-repeat: no-repeat;'></div>
											<div class='member-info'>
												<h2>S. L. Deshmukh</h2>
												<p>Investor and Mentor</p>
											</div>
										</div>
									</div>
												</div>
				<div class="small_team_container" style="display: grid; grid-template-columns: repeat(3, minmax(200px, 1fr)); grid-gap: 30px; margin-top: 80px; grid-row-gap: 70px;">
					
									<div>
										<div class='team-member small'>
											<div class='picture' style='background-image: url(img/team/team_member_4.jpg); background-size: cover; background-position: center; background-repeat: no-repeat;'></div>
											<div class='member-info'>
												<h2>Akshay Kalbhor</h2>
												<p>Project Incharge</p>
											</div>
										</div>
									</div>
								
									<div>
										<div class='team-member small'>
											<div class='picture' style='background-image: url(img/team/team_member_5.jpg); background-size: cover; background-position: center; background-repeat: no-repeat;'></div>
											<div class='member-info'>
												<h2>Sunil Kirodowal</h2>
												<p>Project Incharge</p>
											</div>
										</div>
									</div>
								
									<div>
										<div class='team-member small'>
											<div class='picture' style='background-image: url(img/team/team_member_6.jpg); background-size: cover; background-position: center; background-repeat: no-repeat;'></div>
											<div class='member-info'>
												<h2>Vedika Somani</h2>
												<p>Interior Design Intern</p>
											</div>
										</div>
									</div>
								
									<div>
										<div class='team-member small'>
											<div class='picture' style='background-image: url(img/team/team_member_7.jpg); background-size: cover; background-position: center; background-repeat: no-repeat;'></div>
											<div class='member-info'>
												<h2>Tanvi Rajput</h2>
												<p>Architectural Intern</p>
											</div>
										</div>
									</div>
												</div>
		</div>
	</section>
	<!-- Team section end -->


	<section class="promo-section">
		<div class="container">
			<div class="row">
				<div class="col-lg-9 promo-text">
					<h1>Want to <span class="coloredSpan">speak</span> with us?</h1>
					<p>Feel free to contact us with any question you have, we are happy to serve your architecture and design needs.</p>
				</div>
				<div class="col-lg-3 text-lg-right">
					<a href="contact.php"><button class="borderedBtnDark"><div></div>Get in Touch</button></a>
				</div>
			</div>
		</div>
	</section>

		<section class="cta_visitotherpages" style="    padding: 40px 0;
    background-color: #4e4e5d;">
		<div class="section_inner_container flexH flexAlignStart flexJustifySpaceBet fullW maxW1000">
			<div class="flexV flexAlignStart flexJustifyStart" style="flex: 1;flex-grow: 2;max-width: 500px;color: white;">
				<h2 style="
	    color: white;
	">This is not it, there is a lot more to see!</h2>
				<p style="
	    color: white;
	"> We have a lot more interesting stuff like this, that we bet you will love to see. Click on any of the links to explore more.</p>
			</div>
			<ul class="bulleted_ul">
				<li><a href="index.php#idForServices">Take a look at our services</a></li>
				<li><a href="#">Go to News Feed for the latest updates</a></li>
				<li><a href="portfolio.php">Explore projects we did</a></li>
				<li><a href="contact.php">Get in touch with us</a></li>
			</ul>
		</div>
	</section>



	

	
	<style type="text/css">
		.picture {
			width: 200px;
			height: 200px;
			border-radius: 5px;
		}
		.team-member .member-info {
			padding: 15px 20px;
			width: auto;
		}
		.team-member.small .member-info {
		    position: absolute;
		    padding-left: 21px;
		    padding: 15px;
		    width: 230px;
		    background: #fff;
		    bottom: -20px;
		    right: 5px;
		    -webkit-box-shadow: 6px 7px 20px rgba(114, 114, 114, 0.21);
		    box-shadow: 6px 7px 20px rgba(114, 114, 114, 0.21);
		    -webkit-transition: all 0.4s;
		    -o-transition: all 0.4s;
		    transition: all 0.4s;
		}
		.team-member.small .picture {
			border-radius: 50%;
			border: solid 5px #fff;
		}
		.team-member .member-info h2 {
			font-size: 1.35em;
		}
		.team-member .member-info p {
			opacity: 0.6;
			font-size: 1.15em;
			line-height: 1.1;
			padding: 10px 0 0 0;
		}
		.team-member.small .member-info h2 {
			font-size: 1.35em;
			/*font-weight: 550;*/
		}
		.team-member.small .member-info p {
			opacity: 0.6;
			font-size: 1.15em;
		}
	</style>
	

		
		<footer class="footer-section">
			<div class="footer-social">
				<div class="social-links">
					<!-- <a href="#"><i class="fa fa-pinterest"></i></a> -->
					<!-- <a href="#"><i class="fa fa-linkedin"></i></a> -->
					<a href="https://www.facebook.com/AndSpaces-1257601961076536/"><i class="fab fa-facebook-f"></i></a>
					<a href="https://www.instagram.com/and_spaces/"><i class="fab fa-instagram"></i></a>
					<a href="https://twitter.com/AndSpaces1"><i class="fab fa-twitter"></i></a>
				</div>
			</div>
			<div class="container">
				<div class="row">
					<div class="col-lg-9 offset-lg-3">
						<div class="row">
							<div class="col-md-4">
								<div class="footer-item">
									<ul>
										<li><a href="index.php">Home</a></li>
										<li><a href="about.php">About us</a></li>
										<li><a href="#idForServices">Services</a></li>
										<li><a href="portfolio.php">Portfolio</a></li>
									</ul>
								</div>
							</div>
							<div class="col-md-4">
								<div class="footer-item">
									<ul>
										<li><a href="pay" target="_BLANK"><i class="fas fa-credit-card" style="margin-right: 10px;"></i>Payment Portal</a></li>
										<li><a href="terms.php">Terms & Conditions</a></li>
										<li><a href="privacypolicy.php">Privacy Policy</a></li>
										<li><a href="faq.php">Frequently Asked Questions (FAQs)</a></li>
										<!-- <li><a href="">Job Aplications</a></li> -->
									</ul>
								</div>
							</div>
							<div class="col-md-4">
								<div class="footer-item">
									<ul>
										<li><a href="contact.php">Contact us</a></li>
									</ul>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>

			<hr>

			<div class="flexV flexJustifyCenter flexAlignCenter fullW" style="position: relative; background-color: #14141d; padding-top: 40px; padding-bottom: 20px;">
				<div class="flexH flexJustifyCenter flexAlignCenter" style="position: relative;">
					<div class="footer_newsletter_div flexV flexAlignStart flexJustifyStart" style="width: 100%; color: #fffd;position: relative;">
						<h3 id="newsletter_title" class="flexH flexAlignCenter flexJustifyStart" style="z-index: 1;font-size: 1.05em;color: #b2b2b5;margin-bottom: 20px;">Newsletter subscription</h3>
						<form id="footer_newsletter_form" method="POST" action="proc/newsletter_subscription.php" class="input_box flexH flexAlignStrech flexJustifyCenter" style="margin-bottom: 10px;">
							<input type="email" name="newsletteremail" placeholder="Email address" required="">
							<button>Subscribe</button>
						</form>
						<p id="newsletter_subtitle" style="font-size: 0.8em;">Subscribe to our regular newsletter to get the most important updates as they arive!</p>
						<a id="newsletter_retrybtn" class="animatedBtnLightSmall" style="margin-top: 5px; margin-bottom: 5px; opacity: 0.7; border-radius: 3px; display: none;" onclick="retryNewsletter()"><div></div><i class="fas fa-redo-alt" style="font-size: 15px; margin: 0 10px 0 0;"></i>Try Again</a>
						<div id="newsletter_loader" style="position: absolute;height: 100%;width: 100%;background-color: #14141d;background-repeat: no-repeat;background-size: auto;background-position: left;background-image: url(lib/img/svg_loader.svg); display: none; ">
							<div class="squares_loader_container">
							  <div class="squares_loader"></div>
							</div>
						</div>
					</div>
				</div>
			</div>

		</footer>

		<div class="copyright" style="display: flex; flex-direction: row; align-items: center; justify-content: space-between; background-color: #020203; color: #4e4e5d; font-size: 0.8em; width: 100%; text-align: center; padding: 30px;">
			<p style="margin: 0;font-size: 1em;color: inherit;">
				Copyright
				<script>
					document.write(new Date().getFullYear() + " - " + (new Date().getFullYear() + 1));
				</script>  &copy; AndSpaces -  
				All rights reserved.
			</p>
			<a href="" style="font-size: 1em;color: inherit;">designed by <b style="color: #fff5;">Conceptures</b></a>
		</div>

		<style type="text/css">
			.footer-section {
				padding-bottom: 0;
				padding-top: 60px;
			}
			.footer_newsletter_div .input_box {
			    width: auto;
			    border: solid 1px var(--colorBrand);
			    background-color: #b79054;
			    margin: 5px 0;
			    font-size: 0.8em;
			    letter-spacing: 0.125em;
			    color: var(--colorDark);
			    border: none;
			    border-radius: 5px;
			    background-color: #353535;
			}
			.footer_newsletter_div .input_box input {
			    border: none;
			    padding: 8px 15px;
			    letter-spacing: 0.1em;
			    color: #fffb;
		    	background-color: #30303e;
			    font-size: 1.1em;
			}
			.footer_newsletter_div .input_box button {
			    text-transform: uppercase;
			    padding: 5px 10px;
			    border: none;
			    color: #fffb;
			    border-left: solid 4px var(--colorDark);
			    background-color: #4e4e5d;
			}
			.animatedBtnLightSmall {
			    z-index: 1;
			    position: relative;
			    display: flex;
			    flex-direction: row;
			    align-items: center;
			    justify-content: center;
			    font-size: 0.8em;
			    font-weight: 550;
			    text-transform: uppercase;
			    padding: 5px 20px 5px 15px;
			    margin: 15px 5px 15px -12px;
			    color: #fff;
			    background-color: transparent;
			    transition: 0.45s ease-in-out;
			}
			.animatedBtnLightSmall div {
				z-index: -1;
				position: absolute;
				top: 0;
				left: 0;
				bottom: 0;

				width: 0%;
				height: 100%;

				background-color: #fff;
				transition: 0.45s ease-in-out;
			}
			.animatedBtnLightSmall:hover {
				color: #000 !important;
				margin: 15px 0px;
			}
			.animatedBtnLightSmall:hover div {
				width: 100%;
				transition: 0.45s ease-in-out;
			}
			.animatedBtnLightSmall i,
			.animatedBtnLightSmall i {
				font-size: 20px;
				margin: 0 -8px 0 15px;
			}
		</style>

		<!-- <div class="custom-cursor"></div> -->
		<script src='https://cdnjs.cloudflare.com/ajax/libs/gsap/2.0.1/TweenMax.min.js'></script>

		<script type="text/javascript">
			$(function() {

				$("#newsletter_loader").fadeOut();
				$("#newsletter_retrybtn").fadeOut(0);

				$("#footer_newsletter_form").submit(function(e) {
					e.preventDefault();

					$("#newsletter_loader").fadeIn();

					var form = $(this);

					$.ajax({
						type: "POST",
						url: "proc/newsletter_subscription.php",
						data: form.serialize(),
						dataType    : 'json',
				        encode      : true,
						success: function(data) {
							$("#newsletter_loader").fadeOut();
							if (data.success) {
								subscriptionDone();
							} else {
								subscriptionFailed(data.error);
								$("#newsletter_retrybtn").fadeIn();
							}
						},
						error: function(data) {
							$("#newsletter_loader").fadeOut();
							$("#newsletter_retrybtn").fadeIn();
						}
					});
				});
			});

			function subscriptionDone() {
				$("#footer_newsletter_form").fadeOut(0);
				document.getElementById("newsletter_title").innerHTML = "<i class=\"fas fa-check\" style='margin-right: 10px;'></i>Subscription successfull";
				document.getElementById("newsletter_subtitle").innerHTML = "You have successfully subscribed to the newsletter to receive all the important and latest updates. ";
			}
			function subscriptionFailed(error) {
				$("#footer_newsletter_form").fadeOut(0);
				document.getElementById("newsletter_title").innerHTML = "<i class=\"fas fa-times\" style='margin-right: 10px;'></i>Unable to process";
				document.getElementById("newsletter_subtitle").innerHTML = error;
			}
			function retryNewsletter() {
				$("#footer_newsletter_form").fadeIn(0);
				$("#newsletter_retrybtn").fadeOut(0);
				document.getElementById("newsletter_title").innerHTML = "Newsletter subscription";
				document.getElementById("newsletter_subtitle").innerHTML = "Subscribe to our regular newsletter to get the most important updates as they arive!";
			}
		</script>
		
	<!--Start of Tawk.to Script-->
	<script type="text/javascript">
	var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
	(function(){
	var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
	s1.async=true;
	s1.src='https://embed.tawk.to/5d2da658bfcb827ab0cc0354/default';
	s1.charset='UTF-8';
	s1.setAttribute('crossorigin','*');
	s0.parentNode.insertBefore(s1,s0);
	})();
	</script>
	<!--End of Tawk.to Script-->


	<!--====== Javascripts & Jquery ======-->
	<!-- <script src="js/jquery-2.1.4.min.js"></script> -->
	<script src="js/bootstrap.min.js"></script>
	<script src="js/isotope.pkgd.min.js"></script>
	<script src="js/owl.carousel.min.js"></script>
	<script src="js/jquery.owl-filter.js"></script>
	<script src="js/magnific-popup.min.js"></script>
	<script src="js/circle-progress.min.js"></script>
	<script src="js/main.js"></script>
</body>
<script>'undefined'=== typeof _trfq || (window._trfq = []);'undefined'=== typeof _trfd && (window._trfd=[]),_trfd.push({'tccl.baseHost':'secureserver.net'}),_trfd.push({'ap':'cpsh'},{'server':'sg2plcpnl0218'}) // Monitoring performance to make your website faster. If you want to opt-out, please contact web hosting support.</script><script src='https://img1.wsimg.com/tcc/tcc_l.combined.1.0.6.min.js'></script></html>