
<!DOCTYPE html>
<html lang="en">
<head>
	<title>Andspaces | Architecture - Interior</title>
	<meta charset="UTF-8">
	<meta name="description" content="Architecture and Interiors">
	<meta name="keywords" content="arcade, architecture, onepage, creative, html">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">


	<!-- NO CACHE THING STARTS -->
	<meta http-equiv="cache-control" content="max-age=0">
	<meta http-equiv="cache-control" content="no-store">
	
	<!-- <meta http-equiv="expires" content="0" />
	<meta http-equiv="expires" content="Tue, 01 Jan 1980 1:00:00 GMT" />
	<meta http-equiv="pragma" content="no-cache" /> -->
	<!-- NO CACHE THING ENDS -->

	<!-- <link rel="stylesheet" type="text/css" href="css/aurum.css"> -->


	<!-- Favicon -->   
	<link href="img/favicon.ico" rel="shortcut icon"/>

	<!-- Stylesheets -->
	<link rel="stylesheet" href="css/bootstrap.min.css"/>	<!-- ADDED TO ANDROID APP ASSETS -->
	<link rel="stylesheet" href="css/font-awesome.min.css"/>	<!-- ADDED TO ANDROID APP ASSETS -->
	<link rel="stylesheet" href="css/animate.css"/>	<!-- ADDED TO ANDROID APP ASSETS -->
	<link rel="stylesheet" href="css/owl.carousel.css"/>	<!-- ADDED TO ANDROID APP ASSETS -->

	<!--====== Javascripts & Jquery ======-->
	<script src="js/jquery.min.js"></script>	<!-- ADDED TO ANDROID APP ASSETS -->
	<!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script> -->

	<!-- ANIMATION LIBRARY AOS -->
	<!-- <link rel="stylesheet" href="css/aos.css"/> -->
	<!-- <script src="js/aos.js"></script> -->


	<!--[if lt IE 9]>
	  <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
	  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
	<![endif]-->

	<style type="text/css">
		
		body {
			/*background-color: #fff;*/
			/*background-image: url(img/bg/lineBG1.png);*/
			/*background-size: cover;							*/
		}
		.social-links a {
			display: block;
			color: var(--colorPrimaryDark);
			margin-bottom: 20px;
			font-size: 20px;
			-webkit-transition: all 0.4s;
			-o-transition: all 0.4s;
			transition: all 0.4s;
			opacity: 0.7;
		}

		.social-links a:hover {
			color: var(--colorPrimaryDark);
			opacity: 1;
		}

		.footer-social .social-links a {
			color: #fff;
			opacity: 0.5;
		}
		.footer-social .social-links a:hover {
			color: #fff;
			opacity: 1;
		}

	</style>

</head>
<body>

<!-- 	<script>
	  AOS.init();
	</script>
 -->
	<!-- Page Preloder -->
	<div id="preloder" style="background-color: #f7edec">
	<div class="loader" style="width: 100%; max-width: 120px; text-align: center;">
		<object>
			<embed src="img/animated_logo_dark.svg"></embed>
		</object>
		<!-- <p>Please Wait</p> -->
	</div>
</div>	
	<!-- Header section start -->   
	<img src="img/logoDark_Small.png" style="display: none;">	<!-- ADDED TO ANDROID APP ASSETS -->

	

<link rel="stylesheet" href="css/style.css?v2.4"/>

<link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
<script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
<script>
  AOS.init();
</script>

<link href="https://fonts.googleapis.com/css?family=Poppins:200,400,500,700|Roboto:300,400,500,700&display=swap" rel="stylesheet">

<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">

<!-- <link rel="stylesheet" href="css/custom_cursor.css">   -->

<nav id="headerID" class="header-area unscrolled_header">
	<a href="index.php" class="logo-area">
		<img src="img/logoDark_Small.png" alt="">
	</a>
	<div style="display: flex;flex-direction: column;align-items: flex-start;justify-content: center;/* line-height: 0.5; *//* height: 100%; */">
		<h3 style="letter-spacing: 0.2em;">AndSpaces</h3>
		<p>Architecture - Interior</p>
	</div>

	<div class="nav-switch">
		<i class="fa fa-bars"></i>
	</div>

	<nav class="nav-menu" style="margin-top: -40px; flex: 1; flex-grow: 1;">
		<ul style="float: right;">
			<li id="navbarMenuItemHome"><a href="index.php" style="display: inline-flex; flex-direction: row; align-items: center; justify-content: flex-start;"><i class="fas fa-home"></i><span style="margin-left: 8px;" class="onlyForMobile">Home</span></a></li>
			<li id="navbarMenuItemAbout"><a href="about.php">What is AndSpaces?</a></li>
			<li id="navbarMenuItemPortfolio"><a href="portfolio.php">Our Work</a></li>
			<li id="navbarMenuItemContact"><a href="contact.php"><i class="fas fa-phone" style="transform: rotate(90deg); margin-right: 8px;"></i>Contact</a></li>
			<li id="navbarMenuItemPay"><a href="pay" target="_BLANK"><i class="fas fa-credit-card" style="margin-right: 8px;"></i>Pay</a></li>
		</ul>
	</nav>
</nav>

<script type="text/javascript">
	
	function navOnPage(pageID) {
		$("#" + pageID).addClass("active");
	}

</script>

<!-- <link rel="stylesheet" type="text/css" href="css/dark_theme.css"> -->
	<script type="text/javascript">
		navOnPage("navbarMenuItemHome");	
	</script>
	<!-- Header section end -->   


	<!-- Hero section start -->
	<section class="hero-section">
		<!-- <div class="sectionBGIMG"></div> -->
		<!-- <div class="gradientOverlayLight"></div> -->
		<div id="leftDivBG"></div>
		<div id="leftDivBG2"></div>
		<!-- left social link ber -->
		<div class="left-bar">
			<div class="left-bar-content">
				<div class="social-links">
					<!-- <a href="#"><i class="fa fa-pinterest"></i></a> -->
					<!-- <a href="#"><i class="fa fa-linkedin"></i></a> -->
					<a href="https://www.facebook.com/AndSpaces-1257601961076536/" target="_BLANK"><i class="fab fa-facebook-f"></i></a>
					<a href="https://www.instagram.com/and_spaces/"><i class="fab fa-instagram" target="_BLANK"></i></a>
					<a href="https://twitter.com/AndSpaces1" target="_BLANK"><i class="fab fa-twitter"></i></a>
				</div>
			</div>
		</div>
		<!-- hero slider area -->
		<div class="hero-slider">
			<div class="hero-slide-item">
				<div class="slide-inner">
					<div class="slide-content" data-aos="fade-right">
					<h2 style="text-transform: capitalize; font-size: 2.5em; font-weight: 400;">Designs That Truly<br> <span style="font-size: 1.5em; font-weight: 550;">Speak</span></h2>
					<p style="font-size: 1.1em;">Every design that speaks about its refinement <br> and attention to details.</p>
					<a href="about.php" class="slideShowReadMoreBtn customMouseHoverBtn"><div></div>Read More</a>
					</div>	
				</div>
			</div>
			<div class="hero-slide-item">
				<div class="slide-inner">
					<div class="slide-content" data-aos="fade-right">
					<h2 style="text-transform: capitalize; font-size: 2.5em; font-weight: 400;">Designs That Create <br> <span style="font-size: 1.5em; font-weight: 550;">Aura</span></h2>
					<p style="font-size: 1.1em;">Every detail and touch that feels like <br>it's meant to be!</p>
					<a href="about.php" class="slideShowReadMoreBtn customMouseHoverBtn"><div></div>Read More</a>
					</div>	
				</div>
			</div>
			<div class="hero-slide-item">
				<div class="slide-inner">
					<div class="slide-content" data-aos="fade-right">
					<h2 style="text-transform: capitalize; font-size: 2.5em; font-weight: 400;">Designs That Feel<br> <span style="font-size: 1.5em; font-weight: 550;">Connected</span></h2>
					<p style="font-size: 1.1em;">Every design that feels personalized <br>and connects the place to you.</p>
					<a href="about.php" class="slideShowReadMoreBtn customMouseHoverBtn"><div></div>Read More</a>
					</div>
				</div>
			</div>
		</div>

		
		<div class="hero-right-text">DESIGN</div>
	</section>
	<!-- Hero section end -->


	

	<section id='homeIntroSection' class='singleColumnForMobile' style='display: grid;grid-template-columns: minmax(40%, 1fr) auto;'>
		<div class='pictureDiv' data-aos='fade-up' style='background-image: url(img/bg/new/10.png);background-size: contain;background-position: bottom;background-repeat: no-repeat;'></div>
		<div class='contentDiv' data-aos='fade-left' style='display: grid;grid-template-columns: 1fr;grid-gap: 10px;padding: 90px 30px 50px 30px;'>
			<h2 class='sp-title' style='margin-bottom: 20px; line-height: 1.5;'>Great design innovations for <span style='color: #30303e; font-weight: 550;'>every space</span></h2>
			<p style='line-height: 2.5;'>At AndSpaces, we always take a stance to develop and design any project from scratch to accomplish every single possibility of being truly remarkable, whether it is a large scale infrastructure or a single block.</p>
			<div class='cta-icons' style='display: grid; grid-template-columns: repeat(auto-fit, minmax(100px, 120px)); align-items: end;'>
				<div class='cta-img-icon'>
					<img src='img/icon/dark/1.png' alt=''>
					<p>Residential</p>
				</div>
				<div class='cta-img-icon'>
					<img src='img/icon/dark/3.png' alt=''>
					<p>Corporate</p>
				</div>
				<div class='cta-img-icon'>
					<img src='img/icon/dark/2.png' alt=''>
					<p>Other</p>
				</div>
			</div>
		</div>
	</section>
	<!-- <div style="display: flex; flex-direction: row; align-items: flex-end; justify-content: flex-end; width: 100%;">
		<div style="width: 0;height: 0;border-top: 3.5vw solid #30303e;margin-bottom: -3.5vw;border-left: 75vw solid transparent;z-index: 1;"></div>
	</div> -->

	
	<section class='intro-section' style='background-color: #fff; margin-bottom: 100px; box-shadow: 0px 11px 15px #0001;'>
		<div class='container' style='margin: 0px; padding: 0px; max-width: 100%; overflow: hidden;'>

			<div class='row' style='padding: 80px; display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));'>
				<div class='intro-text mb-5 mb-lg-0'  data-aos='fade-right' style='display: flex; flex-direction: column; align-items: flex-start; justify-content: center; padding: 0 30px;'>
					<h2 class='sp-title' style='line-height: 1.5;'>Every corner of your place deserves to be a design <span class='coloredSpan'> sensation</span></h2>
					<p style='text-align: justify; margin-bottom: 20px; line-height: 2.5;'>Places small and big, they all deserve to be designed in such a way that every piece shall come out to be a true design marvel. We at Andspaces follow the same thirst of crafting every detail at its finest.</p>
					<a href='about.php'class='customMouseHoverBtn dark' style='font-size: 1.1em;'><div></div>Read More</a>
				</div>
				<div  data-aos='fade-up' style='display: flex; flex-direction: row; align-items: center; justify-content: flex-end;'>
					<div style='float: right; margin: 30px; height: 80%; min-height: 250px; width: 80%; background-image: url(img/bg/sofa_on_whitefloor.png); background-position: center; background-size: cover; background-repeat: no-repeat; border: solid 5px #fff; box-shadow: 0px 0px 10px #0004;'>
						<!-- <img src='img/bg/sofa_on_whitefloor.png' alt='' style='float: right; margin: 30px; width: 400px; border: solid 5px #fff; box-shadow: 0px 0px 10px #0004;'> -->
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- Intro section end -->
	<!-- <div style="display: flex; flex-direction: row; align-items: flex-end; justify-content: flex-start; width: 100%;">
		<div style="width: 0;height: 0;border-bottom: 3.5vw solid #30303e;margin-top: -3.5vw;border-right: 75vw solid transparent;z-index: 1;"></div>
	</div> -->


	<!-- Service section start -->
	
	<section id='idForServices' class='service-section spad' style='padding-top: 0px;'>
		<div class='container'>
			<div class='section-title'>
				<h2>Innovative Services</h2>
				<p>Plenty of innovative services to fulfill your design or architectural requirements</p>
			</div>
			<div class='services_container'>
							<div class="service-box" data-aos="fade-up">
								<div class="sb-icon">
									<img src="img/services/1.jpg" alt="">
								</div>
								<h3>Architectural Design</h3>
								<p>Innovative and timeless infrastructure designs, making your building as iconic as the icon itself.</p>
								<a href="Architectural Design/"class="customMouseHoverBtn dark" style="font-size: 1em; margin-top: 20px;"><div></div>Read More</a>
							</div>
							
							<div class="service-box" data-aos="fade-up">
								<div class="sb-icon">
									<img src="img/services/2.jpg" alt="">
								</div>
								<h3>Interior Design</h3>
								<p>Remarkable, premium and meaningful interior design that takes your place to the next level.</p>
								<a href="Interior Design/"class="customMouseHoverBtn dark" style="font-size: 1em; margin-top: 20px;"><div></div>Read More</a>
							</div>
							
							<div class="service-box" data-aos="fade-up">
								<div class="sb-icon">
									<img src="img/services/3.jpg" alt="">
								</div>
								<h3>Personalised Design</h3>
								<p>More customised and personalised designs to give your space a touch of you.</p>
								<a href="Personalised Design/"class="customMouseHoverBtn dark" style="font-size: 1em; margin-top: 20px;"><div></div>Read More</a>
							</div>
							
							<div class="service-box" data-aos="fade-up">
								<div class="sb-icon">
									<img src="img/services/4.jpg" alt="">
								</div>
								<h3>Progressive Design</h3>
								<p>A more dynamic and progressive Development process refined to justify the outcome at first.</p>
								<a href="Progressive Design/"class="customMouseHoverBtn dark" style="font-size: 1em; margin-top: 20px;"><div></div>Read More</a>
							</div>
							
							<div class="service-box" data-aos="fade-up">
								<div class="sb-icon">
									<img src="img/services/5.jpg" alt="">
								</div>
								<h3>All Inclusive</h3>
								<p>A service that has it all to complete your space with everything that you need.</p>
								<a href="All Inclusive/"class="customMouseHoverBtn dark" style="font-size: 1em; margin-top: 20px;"><div></div>Read More</a>
							</div>
							
							<div class="service-box" data-aos="fade-up">
								<div class="sb-icon">
									<img src="img/services/6.jpg" alt="">
								</div>
								<h3>Online Consultation</h3>
								<p>Get experience of  consultation from our expertise sitting at your home. Its online, and affordable.</p>
								<a href="Online Consultation/"class="customMouseHoverBtn dark" style="font-size: 1em; margin-top: 20px;"><div></div>Read More</a>
							</div>
							</div>
		</div>
	</section>
	<!-- Service section end -->
	<!-- Projects section start -->
	
	<div class='projects-section pb50' style='padding: 80px 0;'>
		<div class='container'>
			<div class='row' style='margin: 30px 0;'>
				<div class='section-title' style='margin-bottom: 0;'>
					<h1>Projects</h1>
				</div>
				<ul class='projects-filter-nav' style='margin-top: 10px;'>
					<li class='btn-filter btn-active' data-filter='*'>All</li>
					<li class='btn-filter' data-filter='.cat_inter'>Interior</li>
					<li class='btn-filter' data-filter='.cat_arch'>Architecture</li>
				</ul>
			</div>
		</div>                      
		<div id='projects-carousel' class='projects-slider'>
			<div class='single-project set-bg cat_inter' data-setbg='img/projects/1/2.jpg' data-aos='fade-up'><!-- ADDED TO ANDROID APP ASSETS -->
				<div class='project-content'>
					<h2>Luxurious Living</h2>
					<p>Residential</p>
					<a href='project.php?pid=1'><button class='borderedBtnLight'><div></div>See Project</button></a>
				</div>
			</div>
			<div class='single-project set-bg cat_inter' data-setbg='img/projects/1/11.jpg' data-aos='fade-down'><!-- ADDED TO ANDROID APP ASSETS -->
				<div class='project-content'>
					<h2>Functional Kitchen</h2>
					<p>Residential</p>
					<a href='project.php?pid=1'><button class='borderedBtnLight'><div></div>See Project</button></a>
				</div>
			</div>
			<div class='single-project set-bg cat_inter' data-setbg='img/projects/5.jpg' data-aos='fade-up'><!-- ADDED TO ANDROID APP ASSETS -->
				<div class='project-content'>
					<h2>Retro Futuristic Wood</h2>
					<p>Commercial</p>
					<a href='project.php?pid=2'><button class='borderedBtnLight'><div></div>See Project</button></a>
				</div>
			</div>
			<div class='single-project set-bg build' data-setbg='img/projects/2/5.jpg' data-aos='fade-down'><!-- ADDED TO ANDROID APP ASSETS -->
				<div class='project-content'>
					<h2>Modern Office</h2>
					<p>Commercial</p>
					<a href='project.php?pid=2'><button class='borderedBtnLight'><div></div>See Project</button></a>
				</div>
			</div>
			<div class='single-project set-bg cat_arch' data-setbg='img/projects/5/1.jpg' data-aos='fade-up'><!-- ADDED TO ANDROID APP ASSETS -->
				<div class='project-content'>
					<h2>Bungalow Architecture</h2>
					<p>Residential</p>
					<a href='#'><button class='borderedBtnLight'><div></div>See Project</button></a>
				</div>
			</div>
		</div>
	</div>	<!-- Projects section end -->

	
	<section class='cta_visitotherpages' style='    padding: 40px 0;
    background-color: #4e4e5d;'>
		<div class='section_inner_container flexH flexAlignStart flexJustifySpaceBet fullW maxW1000'>
			<div class='flexV flexAlignStart flexJustifyStart' style='flex: 1;flex-grow: 2;max-width: 500px;color: white;'>
				<h2 style='
	    color: white;
	'>This is not it, there is a lot more to see!</h2>
				<p style='
	    color: white;
	'> We have a lot more interesting stuff like this, that we bet you will love to see. Click on any of the links to explore more.</p>
			</div>
			<ul class='bulleted_ul'>
				<li><a href='about.php'>Read more about AndSpaces</a></li>
				<li><a href='index.php#idForServices'>Take a look at our services</a></li>
				<li><a href='portfolio.php'>Explore our work</a></li>
				<li><a href='contact.php'>Get in touch with us</a></li>
			</ul>
		</div>
	</section>

	<style type="text/css">
		#leftDivBG {
			width: 100%;
			height: 100%;
			position: absolute;
			top: 0;
			left: 0;
			right: 0;
			bottom: 0;
			background-image: url(img/projects/13/1.jpg); /*<!-- ADDED TO ANDROID APP ASSETS -->*/
			background-size: cover;
			background-position: left;
			background-attachment: fixed;
			background-repeat: no-repeat;

			animation-name: homeLeftBGAnimation;
			animation-duration: 80s;
			animation-iteration-count: infinite;
		}
		#leftDivBG2 {
			width: 100%;
			height: 100%;
			position: absolute;
			top: 0;
			left: 0;
			right: 0;
			bottom: 0;
			background-image: linear-gradient(65deg, #090913, transparent);
			background-size: 200%;
		}
		@keyframes homeLeftBGAnimation {
		0% {
			background-image: url(img/projects/1/1.jpg); /*<!-- ADDED TO ANDROID APP ASSETS -->*/
			background-position: center;
		}
		12% {
			background-image: url(img/projects/1/1.jpg); /*<!-- ADDED TO ANDROID APP ASSETS -->*/
			background-position: left;
		}
		13% {
			background-image: url(img/projects/1/3.jpg); /*<!-- ADDED TO ANDROID APP ASSETS -->*/
		}
		25% {
			background-image: url(img/projects/1/3.jpg); /*<!-- ADDED TO ANDROID APP ASSETS -->*/
			background-position: center;
		}
		37% {
			background-image: url(img/projects/2/1.jpg); /*<!-- ADDED TO ANDROID APP ASSETS -->*/
		}
		49% {
			background-image: url(img/projects/2/1.jpg); /*<!-- ADDED TO ANDROID APP ASSETS -->*/
			background-position: left;
		}
		61% {
			background-image: url(img/projects/2/5.jpg); /*<!-- ADDED TO ANDROID APP ASSETS -->*/
		}
		73% {
			background-image: url(img/projects/2/5.jpg); /*<!-- ADDED TO ANDROID APP ASSETS -->*/
			background-position: center;
		}
		74% {
			background-image: url(img/projects/1/11.jpg); /*<!-- ADDED TO ANDROID APP ASSETS -->*/
		}
		86% {
			background-image: url(img/projects/1/11.jpg);	 /*<!-- ADDED TO ANDROID APP ASSETS -->*/
			background-position: left;
		}
		87% {
			background-image: url(img/projects/1/14.jpg); /*<!-- ADDED TO ANDROID APP ASSETS -->*/
		}
		100% {
			background-image: url(img/projects/1/14.jpg); /*<!-- ADDED TO ANDROID APP ASSETS -->*/
			background-position: center;
		}
	}
	</style>
	<style type="text/css">
		.unscrolled_header img {
			content: url(img/logoLight_Small.png) !important; /*<!-- ADDED TO ANDROID APP ASSETS -->*/
		}
		.unscrolled_header h3,
		.unscrolled_header p,
		.unscrolled_header a {
			color: #fff !important;
		}
		.slide-num-holder span {
			color: #00000075;
		}
		.social-links a {
		    color: #fffc;
		}
		.hero-slider .owl-nav .owl-prev, .hero-slider .owl-nav .owl-next {
    		color: #fff5;
		}
	</style>
	
	
		<footer class="footer-section">
			<div class="footer-social">
				<div class="social-links">
					<!-- <a href="#"><i class="fa fa-pinterest"></i></a> -->
					<!-- <a href="#"><i class="fa fa-linkedin"></i></a> -->
					<a href="https://www.facebook.com/AndSpaces-1257601961076536/"><i class="fab fa-facebook-f"></i></a>
					<a href="https://www.instagram.com/and_spaces/"><i class="fab fa-instagram"></i></a>
					<a href="https://twitter.com/AndSpaces1"><i class="fab fa-twitter"></i></a>
				</div>
			</div>
			<div class="container">
				<div class="row">
					<div class="col-lg-9 offset-lg-3">
						<div class="row">
							<div class="col-md-4">
								<div class="footer-item">
									<ul>
										<li><a href="index.php">Home</a></li>
										<li><a href="about.php">About us</a></li>
										<li><a href="#idForServices">Services</a></li>
										<li><a href="portfolio.php">Portfolio</a></li>
									</ul>
								</div>
							</div>
							<div class="col-md-4">
								<div class="footer-item">
									<ul>
										<li><a href="pay" target="_BLANK"><i class="fas fa-credit-card" style="margin-right: 10px;"></i>Payment Portal</a></li>
										<li><a href="terms.php">Terms & Conditions</a></li>
										<li><a href="privacypolicy.php">Privacy Policy</a></li>
										<li><a href="faq.php">Frequently Asked Questions (FAQs)</a></li>
										<!-- <li><a href="">Job Aplications</a></li> -->
									</ul>
								</div>
							</div>
							<div class="col-md-4">
								<div class="footer-item">
									<ul>
										<li><a href="contact.php">Contact us</a></li>
									</ul>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>

			<hr>

			<div class="flexV flexJustifyCenter flexAlignCenter fullW" style="position: relative; background-color: #14141d; padding-top: 40px; padding-bottom: 20px;">
				<div class="flexH flexJustifyCenter flexAlignCenter" style="position: relative;">
					<div class="footer_newsletter_div flexV flexAlignStart flexJustifyStart" style="width: 100%; color: #fffd;position: relative;">
						<h3 id="newsletter_title" class="flexH flexAlignCenter flexJustifyStart" style="z-index: 1;font-size: 1.05em;color: #b2b2b5;margin-bottom: 20px;">Newsletter subscription</h3>
						<form id="footer_newsletter_form" method="POST" action="proc/newsletter_subscription.php" class="input_box flexH flexAlignStrech flexJustifyCenter" style="margin-bottom: 10px;">
							<input type="email" name="newsletteremail" placeholder="Email address" required="">
							<button>Subscribe</button>
						</form>
						<p id="newsletter_subtitle" style="font-size: 0.8em;">Subscribe to our regular newsletter to get the most important updates as they arive!</p>
						<a id="newsletter_retrybtn" class="animatedBtnLightSmall" style="margin-top: 5px; margin-bottom: 5px; opacity: 0.7; border-radius: 3px; display: none;" onclick="retryNewsletter()"><div></div><i class="fas fa-redo-alt" style="font-size: 15px; margin: 0 10px 0 0;"></i>Try Again</a>
						<div id="newsletter_loader" style="position: absolute;height: 100%;width: 100%;background-color: #14141d;background-repeat: no-repeat;background-size: auto;background-position: left;background-image: url(lib/img/svg_loader.svg); display: none; ">
							<div class="squares_loader_container">
							  <div class="squares_loader"></div>
							</div>
						</div>
					</div>
				</div>
			</div>

		</footer>

		<div class="copyright" style="display: flex; flex-direction: row; align-items: center; justify-content: space-between; background-color: #020203; color: #4e4e5d; font-size: 0.8em; width: 100%; text-align: center; padding: 30px;">
			<p style="margin: 0;font-size: 1em;color: inherit;">
				Copyright
				<script>
					document.write(new Date().getFullYear() + " - " + (new Date().getFullYear() + 1));
				</script>  &copy; AndSpaces -  
				All rights reserved.
			</p>
			<a href="" style="font-size: 1em;color: inherit;">designed by <b style="color: #fff5;">Conceptures</b></a>
		</div>

		<style type="text/css">
			.footer-section {
				padding-bottom: 0;
				padding-top: 60px;
			}
			.footer_newsletter_div .input_box {
			    width: auto;
			    border: solid 1px var(--colorBrand);
			    background-color: #b79054;
			    margin: 5px 0;
			    font-size: 0.8em;
			    letter-spacing: 0.125em;
			    color: var(--colorDark);
			    border: none;
			    border-radius: 5px;
			    background-color: #353535;
			}
			.footer_newsletter_div .input_box input {
			    border: none;
			    padding: 8px 15px;
			    letter-spacing: 0.1em;
			    color: #fffb;
		    	background-color: #30303e;
			    font-size: 1.1em;
			}
			.footer_newsletter_div .input_box button {
			    text-transform: uppercase;
			    padding: 5px 10px;
			    border: none;
			    color: #fffb;
			    border-left: solid 4px var(--colorDark);
			    background-color: #4e4e5d;
			}
			.animatedBtnLightSmall {
			    z-index: 1;
			    position: relative;
			    display: flex;
			    flex-direction: row;
			    align-items: center;
			    justify-content: center;
			    font-size: 0.8em;
			    font-weight: 550;
			    text-transform: uppercase;
			    padding: 5px 20px 5px 15px;
			    margin: 15px 5px 15px -12px;
			    color: #fff;
			    background-color: transparent;
			    transition: 0.45s ease-in-out;
			}
			.animatedBtnLightSmall div {
				z-index: -1;
				position: absolute;
				top: 0;
				left: 0;
				bottom: 0;

				width: 0%;
				height: 100%;

				background-color: #fff;
				transition: 0.45s ease-in-out;
			}
			.animatedBtnLightSmall:hover {
				color: #000 !important;
				margin: 15px 0px;
			}
			.animatedBtnLightSmall:hover div {
				width: 100%;
				transition: 0.45s ease-in-out;
			}
			.animatedBtnLightSmall i,
			.animatedBtnLightSmall i {
				font-size: 20px;
				margin: 0 -8px 0 15px;
			}
		</style>

		<!-- <div class="custom-cursor"></div> -->
		<script src='https://cdnjs.cloudflare.com/ajax/libs/gsap/2.0.1/TweenMax.min.js'></script>

		<script type="text/javascript">
			$(function() {

				$("#newsletter_loader").fadeOut();
				$("#newsletter_retrybtn").fadeOut(0);

				$("#footer_newsletter_form").submit(function(e) {
					e.preventDefault();

					$("#newsletter_loader").fadeIn();

					var form = $(this);

					$.ajax({
						type: "POST",
						url: "proc/newsletter_subscription.php",
						data: form.serialize(),
						dataType    : 'json',
				        encode      : true,
						success: function(data) {
							$("#newsletter_loader").fadeOut();
							if (data.success) {
								subscriptionDone();
							} else {
								subscriptionFailed(data.error);
								$("#newsletter_retrybtn").fadeIn();
							}
						},
						error: function(data) {
							$("#newsletter_loader").fadeOut();
							$("#newsletter_retrybtn").fadeIn();
						}
					});
				});
			});

			function subscriptionDone() {
				$("#footer_newsletter_form").fadeOut(0);
				document.getElementById("newsletter_title").innerHTML = "<i class=\"fas fa-check\" style='margin-right: 10px;'></i>Subscription successfull";
				document.getElementById("newsletter_subtitle").innerHTML = "You have successfully subscribed to the newsletter to receive all the important and latest updates. ";
			}
			function subscriptionFailed(error) {
				$("#footer_newsletter_form").fadeOut(0);
				document.getElementById("newsletter_title").innerHTML = "<i class=\"fas fa-times\" style='margin-right: 10px;'></i>Unable to process";
				document.getElementById("newsletter_subtitle").innerHTML = error;
			}
			function retryNewsletter() {
				$("#footer_newsletter_form").fadeIn(0);
				$("#newsletter_retrybtn").fadeOut(0);
				document.getElementById("newsletter_title").innerHTML = "Newsletter subscription";
				document.getElementById("newsletter_subtitle").innerHTML = "Subscribe to our regular newsletter to get the most important updates as they arive!";
			}
		</script>
		
	<!--====== Javascripts & Jquery ======-->
	<!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.4/jquery.min.js"></script> -->

	<script src="js/bootstrap.min.js"></script>	<!-- ADDED TO ANDROID APP ASSETS -->
	<script src="js/isotope.pkgd.min.js"></script>	<!-- ADDED TO ANDROID APP ASSETS -->
	<script src="js/owl.carousel.min.js"></script>	<!-- ADDED TO ANDROID APP ASSETS -->
	<script src="js/jquery.owl-filter.js"></script>	<!-- ADDED TO ANDROID APP ASSETS -->
	<script src="js/magnific-popup.min.js"></script>	<!-- ADDED TO ANDROID APP ASSETS -->
	<script src="js/circle-progress.min.js"></script>	<!-- ADDED TO ANDROID APP ASSETS -->

	<script src="js/main_fullPreloader.js?v1.2"></script>	<!-- ADDED TO ANDROID APP ASSETS -->

	<!-- INTERNAL JAVASCRIPTS -->
	<!-- <script src="js/header_scroll.js"></script> -->

	<!--Start of Tawk.to Script-->
	<script type="text/javascript">
	var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
	(function(){
	var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
	s1.async=true;
	s1.src='https://embed.tawk.to/5d2da658bfcb827ab0cc0354/default';
	s1.charset='UTF-8';
	s1.setAttribute('crossorigin','*');
	s0.parentNode.insertBefore(s1,s0);
	})();
	</script>
	<!--End of Tawk.to Script-->

</body>
<script>'undefined'=== typeof _trfq || (window._trfq = []);'undefined'=== typeof _trfd && (window._trfd=[]),_trfd.push({'tccl.baseHost':'secureserver.net'}),_trfd.push({'ap':'cpsh'},{'server':'sg2plcpnl0218'}) // Monitoring performance to make your website faster. If you want to opt-out, please contact web hosting support.</script><script src='https://img1.wsimg.com/tcc/tcc_l.combined.1.0.6.min.js'></script></html>