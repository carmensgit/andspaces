
<!DOCTYPE html>
<html lang="en">
<head>
	<title>Privacy Policy | Andspaces</title>

	<!-- <base href="/andspaces/"> -->
	<base href="/">

	<meta charset="UTF-8">
	<meta name="description" content="Architecture and Interiors">
	<meta name="keywords" content="arcade, architecture, onepage, creative, html">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<!-- Favicon -->   
	<link href="img/favicon.ico" rel="shortcut icon"/>

	<!-- Google Fonts -->
	<link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700" rel="stylesheet">

	<!-- Stylesheets -->
	<link rel="stylesheet" href="css/bootstrap.min.css"/>
	<link rel="stylesheet" href="css/font-awesome.min.css"/>
	<link rel="stylesheet" href="css/animate.css"/>
	<link rel="stylesheet" href="css/owl.carousel.css"/>

	<link rel="stylesheet" href="css/aurum_min.css?v1.5"/>

	<!--====== Javascripts & Jquery ======-->
	<script src="js/jquery.min.js"></script>
	<!--[if lt IE 9]>
	  <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
	  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
	<![endif]-->

</head>
<body>
	<!-- Page Preloder -->
	<div id="preloder" style="background-color: #f7edec">
	<div class="loader" style="width: 100%; max-width: 120px; text-align: center;">
		<object>
			<embed src="img/animated_logo_dark.svg"></embed>
		</object>
		<!-- <p>Please Wait</p> -->
	</div>
</div>	
	<!-- Header section start -->   
	<img src="img/logoDark_Small.png" style="display: none;">

	<!-- Google Fonts -->
	<link href="https://fonts.googleapis.com/css?family=Poppins:200,400,500,700|Roboto:300,400,500,700&display=swap" rel="stylesheet">

	<!-- <link rel="stylesheet" href="css/custom_cursor.css">   -->

	

<link rel="stylesheet" href="css/style.css?v2.4"/>

<link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
<script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
<script>
  AOS.init();
</script>

<link href="https://fonts.googleapis.com/css?family=Poppins:200,400,500,700|Roboto:300,400,500,700&display=swap" rel="stylesheet">

<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">

<!-- <link rel="stylesheet" href="css/custom_cursor.css">   -->

<nav id="headerID" class="header-area unscrolled_header">
	<a href="index.php" class="logo-area">
		<img src="img/logoDark_Small.png" alt="">
	</a>
	<div style="display: flex;flex-direction: column;align-items: flex-start;justify-content: center;/* line-height: 0.5; *//* height: 100%; */">
		<h3 style="letter-spacing: 0.2em;">AndSpaces</h3>
		<p>Architecture - Interior</p>
	</div>

	<div class="nav-switch">
		<i class="fa fa-bars"></i>
	</div>

	<nav class="nav-menu" style="margin-top: -40px; flex: 1; flex-grow: 1;">
		<ul style="float: right;">
			<li id="navbarMenuItemHome"><a href="index.php" style="display: inline-flex; flex-direction: row; align-items: center; justify-content: flex-start;"><i class="fas fa-home"></i><span style="margin-left: 8px;" class="onlyForMobile">Home</span></a></li>
			<li id="navbarMenuItemAbout"><a href="about.php">What is AndSpaces?</a></li>
			<li id="navbarMenuItemPortfolio"><a href="portfolio.php">Our Work</a></li>
			<li id="navbarMenuItemContact"><a href="contact.php"><i class="fas fa-phone" style="transform: rotate(90deg); margin-right: 8px;"></i>Contact</a></li>
			<li id="navbarMenuItemPay"><a href="pay" target="_BLANK"><i class="fas fa-credit-card" style="margin-right: 8px;"></i>Pay</a></li>
		</ul>
	</nav>
</nav>

<script type="text/javascript">
	
	function navOnPage(pageID) {
		$("#" + pageID).addClass("active");
	}

</script>

<!-- <link rel="stylesheet" type="text/css" href="css/dark_theme.css"> -->	<!-- Header section end -->   

	<div id="titleDiv">
		<h1 style="font-size: 1.5em; color: #fcf3f2;">Privacy Policy for AndSpaces</h1>
		<p style="font-size: 0.8em; color: #fcf3f288;">At andspaces.in, accessible from <a href="https://www.andspaces.in" style="color: #fcf3f299; text-decoration: underline; font-weight: 550;">https://www.andspaces.in</a>, one of our main priorities is the privacy of our visitors. This Privacy Policy document contains types of information that is collected and recorded by andspaces.in and how we use it.</p>
	</div>

	<section id="privacy_policy" class="flexV flexAlignCenter flexJustifyCenter fullW" style="padding: 30px;">
		<div class="section_inner_container fullW maxW1000" style="margin-top: 30px; word-break: break-word;">

			<p>If you have additional questions or require more information about our Privacy Policy, do not hesitate to contact us through email at <a href="mailto:info@andspaces.in">info@andspaces.in</a>.</p>

			<h2>Log Files</h2>

			<p>andspaces.in follows a standard procedure of using log files. These files log visitors when they visit websites. All hosting companies do this and a part of hosting services' analytics. The information collected by log files include internet protocol (IP) addresses, browser type, Internet Service Provider (ISP), date and time stamp, referring/exit pages, and possibly the number of clicks. These are not linked to any information that is personally identifiable. The purpose of the information is for analyzing trends, administering the site, tracking users' movement on the website, and gathering demographic information.</p>

			<h2>Cookies and Web Beacons</h2>

			<p>Like any other website, andspaces.in uses 'cookies'. These cookies are used to store information including visitors' preferences, and the pages on the website that the visitor accessed or visited. The information is used to optimize the users' experience by customizing our web page content based on visitors' browser type and/or other information.</p>

			<h2>Google DoubleClick DART Cookie</h2>

			<p>Google is one of a third-party vendor on our site. It also uses cookies, known as DART cookies, to serve ads to our site visitors based upon their visit to www.website.com and other sites on the internet. However, visitors may choose to decline the use of DART cookies by visiting the Google ad and content network Privacy Policy at the following URL – <a href="https://policies.google.com/technologies/ads">https://policies.google.com/technologies/ads</a></p>

			<h2>Our Advertising Partners</h2>

			<p>Some of advertisers on our site may use cookies and web beacons. Our advertising partners are listed below. Each of our advertising partners has their own Privacy Policy for their policies on user data. For easier access, we hyperlinked to their Privacy Policies below.</p>

			<ul>
			    <li>
			        <p>Google</p>
			        <p><a href="https://policies.google.com/technologies/ads">https://policies.google.com/technologies/ads</a></p>
			    </li>
			</ul>

			<h2>Privacy Policies</h2>

			<p>We only ask for personal information when we truly need it to provide a service to you. We collect it by fair and lawful means, with your knowledge and consent. We also let you know why we’re collecting it and how it will be used.</p>

			<p style="margin: 30px 0 0 0;">We only retain collected information for as long as necessary to provide you with your requested service. What data we store, we’ll protect within commercially acceptable means to prevent loss and theft, as well as unauthorised access, disclosure, copying, use or modification.</p>

			<p style="margin: 30px 0 0 0;">We don’t share any personally identifying information publicly or with third-parties, except when required to by law.</p>

			<p style="margin: 30px 0 0 0;">Our website may link to external sites that are not operated by us. Please be aware that we have no control over the content and practices of these sites, and cannot accept responsibility or liability for their respective privacy policies.</p>

			<P style="margin: 30px 0 0 0;">You may consult this list to find the Privacy Policy for each of the advertising partners of andspaces.in.</p>

			<p style="margin: 30px 0 0 0;">Third-party ad servers or ad networks uses technologies like cookies, JavaScript, or Web Beacons that are used in their respective advertisements and links that appear on andspaces.in, which are sent directly to users' browser. They automatically receive your IP address when this occurs. These technologies are used to measure the effectiveness of their advertising campaigns and/or to personalize the advertising content that you see on websites that you visit.</p>

			<p style="margin: 30px 0 0 0;">Note that andspaces.in has no access to or control over these cookies that are used by third-party advertisers.</p>

			<h2>Third Party Privacy Policies</h2>

			<p>andspaces.in's Privacy Policy does not apply to other advertisers or websites. Thus, we are advising you to consult the respective Privacy Policies of these third-party ad servers for more detailed information. It may include their practices and instructions about how to opt-out of certain options. You may find a complete list of these Privacy Policies and their links here: Privacy Policy Links.</p>

			<p style="margin: 30px 0 0 0;">You can choose to disable cookies through your individual browser options. To know more detailed information about cookie management with specific web browsers, it can be found at the browsers' respective websites. What Are Cookies?</p>

			<h2>Children's Information</h2>

			<p>Another part of our priority is adding protection for children while using the internet. We encourage parents and guardians to observe, participate in, and/or monitor and guide their online activity.</p>

			<p style="margin: 30px 0 0 0;">andspaces.in does not knowingly collect any Personal Identifiable Information from children under the age of 13. If you think that your child provided this kind of information on our website, we strongly encourage you to contact us immediately and we will do our best efforts to promptly remove such information from our records.</p>

			<h2>Online Privacy Policy Only</h2>

			<p>This Privacy Policy applies only to our online activities and is valid for visitors to our website with regards to the information that they shared and/or collect in andspaces.in. This policy is not applicable to any information collected offline or via channels other than this website.</p>

			<h2>Consent</h2>

			<p>By using our website, you hereby consent to our Privacy Policy and agree to its Terms and Conditions.</p>

			<p class="ending_statement">This policy is effective as of 1 July 2019.</p>
		</div>
	</section>


	<style type="text/css">
		html, body {
			height: auto;
			overflow-x: hidden;
		}
		#titleDiv {
			width: 100%;
			padding: 100px 30px;
			text-align: center;
			background-color: #191923;
			margin-top: 100px;
		}

		@media only screen and (max-width: 768px) {
			#titleDiv {
				padding: 150px 30px 70px 30px !important;
				margin-top: 0 !important;
			}
		}
	</style>

	
		<footer class="footer-section">
			<div class="footer-social">
				<div class="social-links">
					<!-- <a href="#"><i class="fa fa-pinterest"></i></a> -->
					<!-- <a href="#"><i class="fa fa-linkedin"></i></a> -->
					<a href="https://www.facebook.com/AndSpaces-1257601961076536/"><i class="fab fa-facebook-f"></i></a>
					<a href="https://www.instagram.com/and_spaces/"><i class="fab fa-instagram"></i></a>
					<a href="https://twitter.com/AndSpaces1"><i class="fab fa-twitter"></i></a>
				</div>
			</div>
			<div class="container">
				<div class="row">
					<div class="col-lg-9 offset-lg-3">
						<div class="row">
							<div class="col-md-4">
								<div class="footer-item">
									<ul>
										<li><a href="index.php">Home</a></li>
										<li><a href="about.php">About us</a></li>
										<li><a href="#idForServices">Services</a></li>
										<li><a href="portfolio.php">Portfolio</a></li>
									</ul>
								</div>
							</div>
							<div class="col-md-4">
								<div class="footer-item">
									<ul>
										<li><a href="pay" target="_BLANK"><i class="fas fa-credit-card" style="margin-right: 10px;"></i>Payment Portal</a></li>
										<li><a href="terms.php">Terms & Conditions</a></li>
										<li><a href="privacypolicy.php">Privacy Policy</a></li>
										<li><a href="faq.php">Frequently Asked Questions (FAQs)</a></li>
										<!-- <li><a href="">Job Aplications</a></li> -->
									</ul>
								</div>
							</div>
							<div class="col-md-4">
								<div class="footer-item">
									<ul>
										<li><a href="contact.php">Contact us</a></li>
									</ul>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>

			<hr>

			<div class="flexV flexJustifyCenter flexAlignCenter fullW" style="position: relative; background-color: #14141d; padding-top: 40px; padding-bottom: 20px;">
				<div class="flexH flexJustifyCenter flexAlignCenter" style="position: relative;">
					<div class="footer_newsletter_div flexV flexAlignStart flexJustifyStart" style="width: 100%; color: #fffd;position: relative;">
						<h3 id="newsletter_title" class="flexH flexAlignCenter flexJustifyStart" style="z-index: 1;font-size: 1.05em;color: #b2b2b5;margin-bottom: 20px;">Newsletter subscription</h3>
						<form id="footer_newsletter_form" method="POST" action="proc/newsletter_subscription.php" class="input_box flexH flexAlignStrech flexJustifyCenter" style="margin-bottom: 10px;">
							<input type="email" name="newsletteremail" placeholder="Email address" required="">
							<button>Subscribe</button>
						</form>
						<p id="newsletter_subtitle" style="font-size: 0.8em;">Subscribe to our regular newsletter to get the most important updates as they arive!</p>
						<a id="newsletter_retrybtn" class="animatedBtnLightSmall" style="margin-top: 5px; margin-bottom: 5px; opacity: 0.7; border-radius: 3px; display: none;" onclick="retryNewsletter()"><div></div><i class="fas fa-redo-alt" style="font-size: 15px; margin: 0 10px 0 0;"></i>Try Again</a>
						<div id="newsletter_loader" style="position: absolute;height: 100%;width: 100%;background-color: #14141d;background-repeat: no-repeat;background-size: auto;background-position: left;background-image: url(lib/img/svg_loader.svg); display: none; ">
							<div class="squares_loader_container">
							  <div class="squares_loader"></div>
							</div>
						</div>
					</div>
				</div>
			</div>

		</footer>

		<div class="copyright" style="display: flex; flex-direction: row; align-items: center; justify-content: space-between; background-color: #020203; color: #4e4e5d; font-size: 0.8em; width: 100%; text-align: center; padding: 30px;">
			<p style="margin: 0;font-size: 1em;color: inherit;">
				Copyright
				<script>
					document.write(new Date().getFullYear() + " - " + (new Date().getFullYear() + 1));
				</script>  &copy; AndSpaces -  
				All rights reserved.
			</p>
			<a href="" style="font-size: 1em;color: inherit;">designed by <b style="color: #fff5;">Conceptures</b></a>
		</div>

		<style type="text/css">
			.footer-section {
				padding-bottom: 0;
				padding-top: 60px;
			}
			.footer_newsletter_div .input_box {
			    width: auto;
			    border: solid 1px var(--colorBrand);
			    background-color: #b79054;
			    margin: 5px 0;
			    font-size: 0.8em;
			    letter-spacing: 0.125em;
			    color: var(--colorDark);
			    border: none;
			    border-radius: 5px;
			    background-color: #353535;
			}
			.footer_newsletter_div .input_box input {
			    border: none;
			    padding: 8px 15px;
			    letter-spacing: 0.1em;
			    color: #fffb;
		    	background-color: #30303e;
			    font-size: 1.1em;
			}
			.footer_newsletter_div .input_box button {
			    text-transform: uppercase;
			    padding: 5px 10px;
			    border: none;
			    color: #fffb;
			    border-left: solid 4px var(--colorDark);
			    background-color: #4e4e5d;
			}
			.animatedBtnLightSmall {
			    z-index: 1;
			    position: relative;
			    display: flex;
			    flex-direction: row;
			    align-items: center;
			    justify-content: center;
			    font-size: 0.8em;
			    font-weight: 550;
			    text-transform: uppercase;
			    padding: 5px 20px 5px 15px;
			    margin: 15px 5px 15px -12px;
			    color: #fff;
			    background-color: transparent;
			    transition: 0.45s ease-in-out;
			}
			.animatedBtnLightSmall div {
				z-index: -1;
				position: absolute;
				top: 0;
				left: 0;
				bottom: 0;

				width: 0%;
				height: 100%;

				background-color: #fff;
				transition: 0.45s ease-in-out;
			}
			.animatedBtnLightSmall:hover {
				color: #000 !important;
				margin: 15px 0px;
			}
			.animatedBtnLightSmall:hover div {
				width: 100%;
				transition: 0.45s ease-in-out;
			}
			.animatedBtnLightSmall i,
			.animatedBtnLightSmall i {
				font-size: 20px;
				margin: 0 -8px 0 15px;
			}
		</style>

		<!-- <div class="custom-cursor"></div> -->
		<script src='https://cdnjs.cloudflare.com/ajax/libs/gsap/2.0.1/TweenMax.min.js'></script>

		<script type="text/javascript">
			$(function() {

				$("#newsletter_loader").fadeOut();
				$("#newsletter_retrybtn").fadeOut(0);

				$("#footer_newsletter_form").submit(function(e) {
					e.preventDefault();

					$("#newsletter_loader").fadeIn();

					var form = $(this);

					$.ajax({
						type: "POST",
						url: "proc/newsletter_subscription.php",
						data: form.serialize(),
						dataType    : 'json',
				        encode      : true,
						success: function(data) {
							$("#newsletter_loader").fadeOut();
							if (data.success) {
								subscriptionDone();
							} else {
								subscriptionFailed(data.error);
								$("#newsletter_retrybtn").fadeIn();
							}
						},
						error: function(data) {
							$("#newsletter_loader").fadeOut();
							$("#newsletter_retrybtn").fadeIn();
						}
					});
				});
			});

			function subscriptionDone() {
				$("#footer_newsletter_form").fadeOut(0);
				document.getElementById("newsletter_title").innerHTML = "<i class=\"fas fa-check\" style='margin-right: 10px;'></i>Subscription successfull";
				document.getElementById("newsletter_subtitle").innerHTML = "You have successfully subscribed to the newsletter to receive all the important and latest updates. ";
			}
			function subscriptionFailed(error) {
				$("#footer_newsletter_form").fadeOut(0);
				document.getElementById("newsletter_title").innerHTML = "<i class=\"fas fa-times\" style='margin-right: 10px;'></i>Unable to process";
				document.getElementById("newsletter_subtitle").innerHTML = error;
			}
			function retryNewsletter() {
				$("#footer_newsletter_form").fadeIn(0);
				$("#newsletter_retrybtn").fadeOut(0);
				document.getElementById("newsletter_title").innerHTML = "Newsletter subscription";
				document.getElementById("newsletter_subtitle").innerHTML = "Subscribe to our regular newsletter to get the most important updates as they arive!";
			}
		</script>
		
	<!--====== Javascripts & Jquery ======-->
	<!-- <script src="js/jquery-2.1.4.min.js"></script> -->
	<script src="js/bootstrap.min.js"></script>
	<script src="js/isotope.pkgd.min.js"></script>
	<script src="js/owl.carousel.min.js"></script>
	<script src="js/jquery.owl-filter.js"></script>
	<script src="js/magnific-popup.min.js"></script>
	<script src="js/circle-progress.min.js"></script>
	<script src="js/main.js"></script>

</body>
<script>'undefined'=== typeof _trfq || (window._trfq = []);'undefined'=== typeof _trfd && (window._trfd=[]),_trfd.push({'tccl.baseHost':'secureserver.net'}),_trfd.push({'ap':'cpsh'},{'server':'sg2plcpnl0218'}) // Monitoring performance to make your website faster. If you want to opt-out, please contact web hosting support.</script><script src='https://img1.wsimg.com/tcc/tcc_l.combined.1.0.6.min.js'></script></html>