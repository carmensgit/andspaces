
<!DOCTYPE html>
<html lang="en">
<head>
	<title>Terms and conditions | Andspaces</title>

	<!-- <base href="/andspaces/"> -->
	<base href="/">

	<meta charset="UTF-8">
	<meta name="description" content="Architecture and Interiors">
	<meta name="keywords" content="arcade, architecture, onepage, creative, html">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<!-- Favicon -->   
	<link href="img/favicon.ico" rel="shortcut icon"/>

	<!-- Google Fonts -->
	<link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700" rel="stylesheet">

	<!-- Stylesheets -->
	<link rel="stylesheet" href="css/bootstrap.min.css"/>
	<link rel="stylesheet" href="css/font-awesome.min.css"/>
	<link rel="stylesheet" href="css/animate.css"/>
	<link rel="stylesheet" href="css/owl.carousel.css"/>

	<link rel="stylesheet" href="css/aurum_min.css?v1.5"/>

	<!--====== Javascripts & Jquery ======-->
	<script src="js/jquery.min.js"></script>
	<!--[if lt IE 9]>
	  <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
	  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
	<![endif]-->

</head>
<body>
	<!-- Page Preloder -->
	<div id="preloder" style="background-color: #f7edec">
	<div class="loader" style="width: 100%; max-width: 120px; text-align: center;">
		<object>
			<embed src="img/animated_logo_dark.svg"></embed>
		</object>
		<!-- <p>Please Wait</p> -->
	</div>
</div>	
	<!-- Header section start -->   
	<img src="img/logoDark_Small.png" style="display: none;">

	<!-- Google Fonts -->
	<link href="https://fonts.googleapis.com/css?family=Poppins:200,400,500,700|Roboto:300,400,500,700&display=swap" rel="stylesheet">

	<!-- <link rel="stylesheet" href="css/custom_cursor.css">   -->

	

<link rel="stylesheet" href="css/style.css?v2.4"/>

<link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
<script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
<script>
  AOS.init();
</script>

<link href="https://fonts.googleapis.com/css?family=Poppins:200,400,500,700|Roboto:300,400,500,700&display=swap" rel="stylesheet">

<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">

<!-- <link rel="stylesheet" href="css/custom_cursor.css">   -->

<nav id="headerID" class="header-area unscrolled_header">
	<a href="index.php" class="logo-area">
		<img src="img/logoDark_Small.png" alt="">
	</a>
	<div style="display: flex;flex-direction: column;align-items: flex-start;justify-content: center;/* line-height: 0.5; *//* height: 100%; */">
		<h3 style="letter-spacing: 0.2em;">AndSpaces</h3>
		<p>Architecture - Interior</p>
	</div>

	<div class="nav-switch">
		<i class="fa fa-bars"></i>
	</div>

	<nav class="nav-menu" style="margin-top: -40px; flex: 1; flex-grow: 1;">
		<ul style="float: right;">
			<li id="navbarMenuItemHome"><a href="index.php" style="display: inline-flex; flex-direction: row; align-items: center; justify-content: flex-start;"><i class="fas fa-home"></i><span style="margin-left: 8px;" class="onlyForMobile">Home</span></a></li>
			<li id="navbarMenuItemAbout"><a href="about.php">What is AndSpaces?</a></li>
			<li id="navbarMenuItemPortfolio"><a href="portfolio.php">Our Work</a></li>
			<li id="navbarMenuItemContact"><a href="contact.php"><i class="fas fa-phone" style="transform: rotate(90deg); margin-right: 8px;"></i>Contact</a></li>
			<li id="navbarMenuItemPay"><a href="pay" target="_BLANK"><i class="fas fa-credit-card" style="margin-right: 8px;"></i>Pay</a></li>
		</ul>
	</nav>
</nav>

<script type="text/javascript">
	
	function navOnPage(pageID) {
		$("#" + pageID).addClass("active");
	}

</script>

<!-- <link rel="stylesheet" type="text/css" href="css/dark_theme.css"> -->	<!-- Header section end -->   

	<div id="titleDiv">
		<h1 style="font-size: 1.5em; color: #fcf3f2;">Terms and Conditions of Service</h1>
		<p style="font-size: 0.8em; color: #fcf3f288;">By accessing the website at <a href="https://www.andspaces.in" style="color: #fcf3f299; text-decoration: underline; font-weight: 550;">https://www.andspaces.in</a>, you are agreeing to be bound by these terms of service, all applicable laws and regulations, and agree that you are responsible for compliance with any applicable local laws. If you do not agree with any of these terms, you are prohibited from using or accessing this site. The materials contained in this website are protected by applicable copyright and trademark law.</p>
	</div>

	<section id="privacy_policy" class="flexV flexAlignCenter flexJustifyCenter fullW" style="padding: 30px;">
		<div class="section_inner_container fullW maxW1000" style="margin-top: 30px; word-break: break-word;">

			<h3>1. Terms</h3>
		<p>By accessing the website at <a href="https://www.andspaces.in">https://www.andspaces.in</a>, you are agreeing to be bound by these terms of service, all applicable laws and regulations, and agree that you are responsible for compliance with any applicable local laws. If you do not agree with any of these terms, you are prohibited from using or accessing this site. The materials contained in this website are protected by applicable copyright and trademark law.</p>
		<h3>2. Use License</h3>
		<ol>
		   <li>Permission is granted to temporarily download one copy of the materials (information or software) on AndSpaces' website for personal, non-commercial transitory viewing only. This is the grant of a license, not a transfer of title, and under this license you may not:
		   <ol class="bulleted_ul" style="margin-top: 30px;">
		       <li>modify or copy the materials;</li>
		       <li>use the materials for any commercial purpose, or for any public display (commercial or non-commercial);</li>
		       <li>attempt to decompile or reverse engineer any software contained on AndSpaces' website;</li>
		       <li>remove any copyright or other proprietary notations from the materials; or</li>
		       <li>transfer the materials to another person or "mirror" the materials on any other server.</li>
		   </ol>
		    </li>
		   <li style="margin-top: 30px;">This license shall automatically terminate if you violate any of these restrictions and may be terminated by AndSpaces at any time. Upon terminating your viewing of these materials or upon the termination of this license, you must destroy any downloaded materials in your possession whether in electronic or printed format.</li>
		</ol>
		<h3>3. Disclaimer</h3>
		<ol class="bulleted_ul">
		   <li>The materials on AndSpaces' website are provided on an 'as is' basis. AndSpaces makes no warranties, expressed or implied, and hereby disclaims and negates all other warranties including, without limitation, implied warranties or conditions of merchantability, fitness for a particular purpose, or non-infringement of intellectual property or other violation of rights.</li>
		   <li style="margin-top: 30px;">Further, AndSpaces does not warrant or make any representations concerning the accuracy, likely results, or reliability of the use of the materials on its website or otherwise relating to such materials or on any sites linked to this site.</li>
		</ol>
		<h3>4. Limitations</h3>
		<p>In no event shall AndSpaces or its suppliers be liable for any damages (including, without limitation, damages for loss of data or profit, or due to business interruption) arising out of the use or inability to use the materials on AndSpaces' website, even if AndSpaces or a AndSpaces authorized representative has been notified orally or in writing of the possibility of such damage. Because some jurisdictions do not allow limitations on implied warranties, or limitations of liability for consequential or incidental damages, these limitations may not apply to you.</p>
		<h3>5. Accuracy of materials</h3>
		<p>The materials appearing on AndSpaces' website could include technical, typographical, or photographic errors. AndSpaces does not warrant that any of the materials on its website are accurate, complete or current. AndSpaces may make changes to the materials contained on its website at any time without notice. However AndSpaces does not make any commitment to update the materials.</p>
		<h3>6. Links</h3>
		<p>AndSpaces has not reviewed all of the sites linked to its website and is not responsible for the contents of any such linked site. The inclusion of any link does not imply endorsement by AndSpaces of the site. Use of any such linked website is at the user's own risk.</p>
		<h3>7. Modifications</h3>
		<p>AndSpaces may revise these terms of service for its website at any time without notice. By using this website you are agreeing to be bound by the then current version of these terms of service.</p>
		<h3>8. Governing Law</h3>
		<p>These terms and conditions are governed by and construed in accordance with the laws of Maharashtra, India and you irrevocably submit to the exclusive jurisdiction of the courts in that State or location.</p>

		<p>If you have additional questions or require more information about our Privacy Policy, do not hesitate to contact us through email at <a href="mailto:info@andspaces.in">info@andspaces.in</a>.</p>

		<p class="ending_statement">These terms and conditions and are effective as of 1 July 2019.</p>
		</div>
	</section>


	<style type="text/css">
		html, body {
			height: auto;
			overflow-x: hidden;
		}
		#titleDiv {
			width: 100%;
			padding: 100px 30px;
			text-align: center;
			background-color: #191923;
			margin-top: 100px;
		}

		@media only screen and (max-width: 768px) {
			#titleDiv {
				padding: 150px 30px 70px 30px !important;
				margin-top: 0 !important;
			}
		}
	</style>

	
		<footer class="footer-section">
			<div class="footer-social">
				<div class="social-links">
					<!-- <a href="#"><i class="fa fa-pinterest"></i></a> -->
					<!-- <a href="#"><i class="fa fa-linkedin"></i></a> -->
					<a href="https://www.facebook.com/AndSpaces-1257601961076536/"><i class="fab fa-facebook-f"></i></a>
					<a href="https://www.instagram.com/and_spaces/"><i class="fab fa-instagram"></i></a>
					<a href="https://twitter.com/AndSpaces1"><i class="fab fa-twitter"></i></a>
				</div>
			</div>
			<div class="container">
				<div class="row">
					<div class="col-lg-9 offset-lg-3">
						<div class="row">
							<div class="col-md-4">
								<div class="footer-item">
									<ul>
										<li><a href="index.php">Home</a></li>
										<li><a href="about.php">About us</a></li>
										<li><a href="#idForServices">Services</a></li>
										<li><a href="portfolio.php">Portfolio</a></li>
									</ul>
								</div>
							</div>
							<div class="col-md-4">
								<div class="footer-item">
									<ul>
										<li><a href="pay" target="_BLANK"><i class="fas fa-credit-card" style="margin-right: 10px;"></i>Payment Portal</a></li>
										<li><a href="terms.php">Terms & Conditions</a></li>
										<li><a href="privacypolicy.php">Privacy Policy</a></li>
										<li><a href="faq.php">Frequently Asked Questions (FAQs)</a></li>
										<!-- <li><a href="">Job Aplications</a></li> -->
									</ul>
								</div>
							</div>
							<div class="col-md-4">
								<div class="footer-item">
									<ul>
										<li><a href="contact.php">Contact us</a></li>
									</ul>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>

			<hr>

			<div class="flexV flexJustifyCenter flexAlignCenter fullW" style="position: relative; background-color: #14141d; padding-top: 40px; padding-bottom: 20px;">
				<div class="flexH flexJustifyCenter flexAlignCenter" style="position: relative;">
					<div class="footer_newsletter_div flexV flexAlignStart flexJustifyStart" style="width: 100%; color: #fffd;position: relative;">
						<h3 id="newsletter_title" class="flexH flexAlignCenter flexJustifyStart" style="z-index: 1;font-size: 1.05em;color: #b2b2b5;margin-bottom: 20px;">Newsletter subscription</h3>
						<form id="footer_newsletter_form" method="POST" action="proc/newsletter_subscription.php" class="input_box flexH flexAlignStrech flexJustifyCenter" style="margin-bottom: 10px;">
							<input type="email" name="newsletteremail" placeholder="Email address" required="">
							<button>Subscribe</button>
						</form>
						<p id="newsletter_subtitle" style="font-size: 0.8em;">Subscribe to our regular newsletter to get the most important updates as they arive!</p>
						<a id="newsletter_retrybtn" class="animatedBtnLightSmall" style="margin-top: 5px; margin-bottom: 5px; opacity: 0.7; border-radius: 3px; display: none;" onclick="retryNewsletter()"><div></div><i class="fas fa-redo-alt" style="font-size: 15px; margin: 0 10px 0 0;"></i>Try Again</a>
						<div id="newsletter_loader" style="position: absolute;height: 100%;width: 100%;background-color: #14141d;background-repeat: no-repeat;background-size: auto;background-position: left;background-image: url(lib/img/svg_loader.svg); display: none; ">
							<div class="squares_loader_container">
							  <div class="squares_loader"></div>
							</div>
						</div>
					</div>
				</div>
			</div>

		</footer>

		<div class="copyright" style="display: flex; flex-direction: row; align-items: center; justify-content: space-between; background-color: #020203; color: #4e4e5d; font-size: 0.8em; width: 100%; text-align: center; padding: 30px;">
			<p style="margin: 0;font-size: 1em;color: inherit;">
				Copyright
				<script>
					document.write(new Date().getFullYear() + " - " + (new Date().getFullYear() + 1));
				</script>  &copy; AndSpaces -  
				All rights reserved.
			</p>
			<a href="" style="font-size: 1em;color: inherit;">designed by <b style="color: #fff5;">Conceptures</b></a>
		</div>

		<style type="text/css">
			.footer-section {
				padding-bottom: 0;
				padding-top: 60px;
			}
			.footer_newsletter_div .input_box {
			    width: auto;
			    border: solid 1px var(--colorBrand);
			    background-color: #b79054;
			    margin: 5px 0;
			    font-size: 0.8em;
			    letter-spacing: 0.125em;
			    color: var(--colorDark);
			    border: none;
			    border-radius: 5px;
			    background-color: #353535;
			}
			.footer_newsletter_div .input_box input {
			    border: none;
			    padding: 8px 15px;
			    letter-spacing: 0.1em;
			    color: #fffb;
		    	background-color: #30303e;
			    font-size: 1.1em;
			}
			.footer_newsletter_div .input_box button {
			    text-transform: uppercase;
			    padding: 5px 10px;
			    border: none;
			    color: #fffb;
			    border-left: solid 4px var(--colorDark);
			    background-color: #4e4e5d;
			}
			.animatedBtnLightSmall {
			    z-index: 1;
			    position: relative;
			    display: flex;
			    flex-direction: row;
			    align-items: center;
			    justify-content: center;
			    font-size: 0.8em;
			    font-weight: 550;
			    text-transform: uppercase;
			    padding: 5px 20px 5px 15px;
			    margin: 15px 5px 15px -12px;
			    color: #fff;
			    background-color: transparent;
			    transition: 0.45s ease-in-out;
			}
			.animatedBtnLightSmall div {
				z-index: -1;
				position: absolute;
				top: 0;
				left: 0;
				bottom: 0;

				width: 0%;
				height: 100%;

				background-color: #fff;
				transition: 0.45s ease-in-out;
			}
			.animatedBtnLightSmall:hover {
				color: #000 !important;
				margin: 15px 0px;
			}
			.animatedBtnLightSmall:hover div {
				width: 100%;
				transition: 0.45s ease-in-out;
			}
			.animatedBtnLightSmall i,
			.animatedBtnLightSmall i {
				font-size: 20px;
				margin: 0 -8px 0 15px;
			}
		</style>

		<!-- <div class="custom-cursor"></div> -->
		<script src='https://cdnjs.cloudflare.com/ajax/libs/gsap/2.0.1/TweenMax.min.js'></script>

		<script type="text/javascript">
			$(function() {

				$("#newsletter_loader").fadeOut();
				$("#newsletter_retrybtn").fadeOut(0);

				$("#footer_newsletter_form").submit(function(e) {
					e.preventDefault();

					$("#newsletter_loader").fadeIn();

					var form = $(this);

					$.ajax({
						type: "POST",
						url: "proc/newsletter_subscription.php",
						data: form.serialize(),
						dataType    : 'json',
				        encode      : true,
						success: function(data) {
							$("#newsletter_loader").fadeOut();
							if (data.success) {
								subscriptionDone();
							} else {
								subscriptionFailed(data.error);
								$("#newsletter_retrybtn").fadeIn();
							}
						},
						error: function(data) {
							$("#newsletter_loader").fadeOut();
							$("#newsletter_retrybtn").fadeIn();
						}
					});
				});
			});

			function subscriptionDone() {
				$("#footer_newsletter_form").fadeOut(0);
				document.getElementById("newsletter_title").innerHTML = "<i class=\"fas fa-check\" style='margin-right: 10px;'></i>Subscription successfull";
				document.getElementById("newsletter_subtitle").innerHTML = "You have successfully subscribed to the newsletter to receive all the important and latest updates. ";
			}
			function subscriptionFailed(error) {
				$("#footer_newsletter_form").fadeOut(0);
				document.getElementById("newsletter_title").innerHTML = "<i class=\"fas fa-times\" style='margin-right: 10px;'></i>Unable to process";
				document.getElementById("newsletter_subtitle").innerHTML = error;
			}
			function retryNewsletter() {
				$("#footer_newsletter_form").fadeIn(0);
				$("#newsletter_retrybtn").fadeOut(0);
				document.getElementById("newsletter_title").innerHTML = "Newsletter subscription";
				document.getElementById("newsletter_subtitle").innerHTML = "Subscribe to our regular newsletter to get the most important updates as they arive!";
			}
		</script>
		
	<!--====== Javascripts & Jquery ======-->
	<!-- <script src="js/jquery-2.1.4.min.js"></script> -->
	<script src="js/bootstrap.min.js"></script>
	<script src="js/isotope.pkgd.min.js"></script>
	<script src="js/owl.carousel.min.js"></script>
	<script src="js/jquery.owl-filter.js"></script>
	<script src="js/magnific-popup.min.js"></script>
	<script src="js/circle-progress.min.js"></script>
	<script src="js/main.js"></script>

</body>
<script>'undefined'=== typeof _trfq || (window._trfq = []);'undefined'=== typeof _trfd && (window._trfd=[]),_trfd.push({'tccl.baseHost':'secureserver.net'}),_trfd.push({'ap':'cpsh'},{'server':'sg2plcpnl0218'}) // Monitoring performance to make your website faster. If you want to opt-out, please contact web hosting support.</script><script src='https://img1.wsimg.com/tcc/tcc_l.combined.1.0.6.min.js'></script></html>